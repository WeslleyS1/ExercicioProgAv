import java.util.ArrayList;

public class Produto {
    private String name;
    private int quant;
    private double valor;
    private int quantestoque;

    public int getQuantestoque() {
        return quantestoque;
    }
    public void setQuantestoque(int quantestoque) {
        this.quantestoque = quantestoque;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuant() {
        return quant;
    }

    public void setQuant(int quant) {
        this.quant = quant;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void BaixaEstoque(int vol){
        if (quantestoque >= vol) {
            quantestoque-=vol;
            System.out.println("\n-------------------------------------------------------------------\n" +
                    "O valor total da sua compra foi de: "+getQuant()*getValor()+"\n"+
                    "O(s) produto(s) será entregue na sua casa." +
                    "\n-------------------------------------------------------------------\n");
        }else {
            System.out.println("\n-------------------------------------------------------------------\n" +
                    "Não possui a quantidade de produtos desejada." +
                    "\n-------------------------------------------------------------------\n");
        }
    };
    public void adicionaEstoque(int vol){
        quantestoque+=vol;
    };
    public void Imprimeinventario(){
        System.out.println( "\n-------------------------------------------------------------------\n" +
                "O produto " + getName() + " possui " + getQuant() + " em estoque pelo valor de " + getValor() + " reais." +
                "\n-------------------------------------------------------------------\n");
    };




}