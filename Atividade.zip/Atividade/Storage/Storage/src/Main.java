import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int escolha=0;
        Scanner descricao = new Scanner(System.in);
        Scanner volume = new Scanner(System.in);
        Scanner preco = new Scanner(System.in);
        Scanner codigo = new Scanner(System.in);
        Scanner input = new Scanner(System.in);

        Produto produto = new Produto();

        do {
            System.out.println("-------------------------------------------------------------------\n" +
                    "Escolha a opção desejada: \n 1. Frente de Caixa. \n 2. Adicionar novo produto. \n 3. Imprimir o inventário. \n 4. Encerrar." +
                    "\n-------------------------------------------------------------------\n");

            escolha = input.nextInt();
            switch (escolha) {

                case 1: {
                    System.out.println("\n-------------------------------------------------------------------\n" +
                            "Qual o código do produto que você deseja comprar? " +
                            "\n-------------------------------------------------------------------\n");
                    int cod = codigo.nextInt();

                    System.out.println("\n-------------------------------------------------------------------\n" +
                            "Quantos desse produto você quer levar?" +
                            "\n-------------------------------------------------------------------\n ");
                    int quant = volume.nextInt();
                    produto.BaixaEstoque(quant);
                    break;
                }

                case 2: {
                    System.out.println("\n-------------------------------------------------------------------\n" +
                            "Qual o nome do produto? " +
                            "\n-------------------------------------------------------------------\n");
                    String nome = descricao.next();
                    produto.setName(nome);

                    System.out.println("\n-------------------------------------------------------------------\n" +
                            "Qual é a quantidade do produto?" +
                            "\n-------------------------------------------------------------------\n ");
                    int quant = volume.nextInt();
                    produto.setQuant(quant);
                    produto.adicionaEstoque(quant);

                    System.out.println("\n-------------------------------------------------------------------\n" +
                            "Qual o valor do produto? " +
                            "\n-------------------------------------------------------------------\n");
                    double valor = preco.nextDouble();
                    produto.setValor(valor);

                    System.out.println("\n-------------------------------------------------------------------\n" +
                            "Deseja cadastrar mais produtos? \n 1- Sim \n 0-Não" +
                            "\n-------------------------------------------------------------------\n ");
                    escolha = input.nextInt();
                    break;
                }

                case 3: {
                    produto.Imprimeinventario();
                }
            }
        } while (escolha != 4);
    }
}

